export const firebaseConfig = {
  apiKey: "AIzaSyDemo-KEY-EXAMPLE",
  authDomain: "demo-project.firebaseapp.com",
  projectId: "demo-project",
  storageBucket: "demo-project.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:example123"
};
