import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { initializeApp } from 'firebase/app';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { firebaseConfig } from './firebaseConfig.js';

const app = express();
app.use(cors());
app.use(express.json());

initializeApp(firebaseConfig);
const storage = getStorage();

const upload = multer({ storage: multer.memoryStorage() });

app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    const { title, description } = req.body;
    const file = req.file;
    if (!file) return res.status(400).send('No file uploaded');

    const storageRef = ref(storage, `uploads/${file.originalname}`);
    await uploadBytes(storageRef, file.buffer);
    const url = await getDownloadURL(storageRef);

    res.json({ message: 'Upload successful', title, description, url });
  } catch (error) {
    console.error(error);
    res.status(500).send('Upload failed');
  }
});

app.get('/', (req, res) => res.send('GD Minor Project Server Running'));
app.listen(5000, () => console.log('Server running on port 5000'));
