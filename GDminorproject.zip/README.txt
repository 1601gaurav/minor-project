# GDminorproject - Water Leakage Detection System

## Project by Gaurav & Divyansh, MITS DU GWALIOR

### Static Version
Contains a simple website describing the project.

### Dynamic Version
Includes:
- React frontend
- Node.js Express backend
- Firebase Storage for file uploads

To run locally:
```bash
cd dynamic-version
npm install
npm run dev
```

To deploy:
Push to GitHub → Import to Vercel → Deploy.
